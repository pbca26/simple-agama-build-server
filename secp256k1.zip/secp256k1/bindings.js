'use strict'
module.exports = require('bindings')('secp256k1')
